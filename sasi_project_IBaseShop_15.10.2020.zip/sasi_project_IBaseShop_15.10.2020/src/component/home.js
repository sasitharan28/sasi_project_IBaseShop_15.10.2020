import React,{Component} from 'react';
import Banner from './images/banner.jpg';
import './css/home.css';
import { Route, Link, BrowserRouter as Router, Switch } from 'react-router-dom';
import Rating from 'material-ui-rating';
import {Grid,Paper,Card,CardContent,Typography,Button, CardActions,CardMedia,CardActionArea,Box} from '@material-ui/core';


import {DataContext} from '../component/Data'
import './css/ShopSide.css'
import ApiService from "./../ApiService";



class Home extends Component {
  constructor(props){
    super(props)
    this.state={
      products:[],
    }
  }

  componentDidMount(){
      this.loadProducts()
  }

  loadProducts = () => {
      ApiService.getAllProducts(0,12)
      .then(res => {
          this.setState({
              products:res.data.data,
          })
      })
  }



  static contextType = DataContext;

  render(){
    const {addCart,buythins} = this.context;
    const products = this.state.products;
    return(
      <div className='Home' style={{backgroundColor:'#d4e3fc'}}>
        <div className='homeImgDiv' style={{display:'flex',margin:'auto',marginTop:'50px'}}>
          <div className='homeImgWar'>
            <img src={Banner} className='homeImg' style={{display:'flex',margin:'auto'}} />

          </div>
        </div>
          <div style={{width:'90%',margin:'auto',marginTop:'50px'}}>
              <Grid container >
                  {products.map(product =>(
                        <Grid item xs={6} sm={4} md={3} lg={3} style={{marginTop:'20px'}}  >
                                <Card className='productCard' key={product.id}  elevation={3}>
                                  <CardActionArea href={'/product/'+product.productId}>
                                    <Box className='showImgDiv'>
                                      <CardMedia
                                        className='showImg'
                                        component="img"
                                        image={product.image1}
                                        title="Contemplative Reptile"
                                        class="img-responsive"
                                        id="showImg"

                                      />
                                    </Box>
                                    <CardContent>
                                      <Typography gutterBottom  className='productTitle'>
                                      {product.title}
                                      </Typography>
                                      <Typography className='offerPrice' variant="h6">
                                        {product.lastPrice}
                                      </Typography>
                                        <Typography className='sellPrice' variant="h6">
                                        {product.sellPrice}
                                        </Typography>

                                        <Typography className='offerPrice'>
                                            <Rating name="read-only" value={product.rating} readOnly style={{}} />
                                        </Typography>
                                    </CardContent>
                                  </CardActionArea>
                                  <CardActions >
                                  <Button variant="contained" id="btn" style={{backgroundColor:'#03a9f4',color:'white',margin:'auto'}} onClick={()=> buythins(product.productId)} >
                                  Buy
                                  </Button>
                                  <Button variant="contained" onClick={()=> addCart(product.productId)} style={{backgroundColor:'#03a9f4',color:'white',margin:'auto'}} >
                                  Add cart
                                  </Button>


                                  </CardActions>

                                </Card>
                        </Grid>
                  ))}
              </Grid>
          </div>
      </div>
    );
  }
}

export default Home;
