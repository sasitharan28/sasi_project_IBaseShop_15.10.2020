import React, { Component } from 'react';
import { CardActionArea,CardMedia,Paper,Divider } from '@material-ui/core';
import { Card, CardContent, Grid, FormControl, TextField, InputLabel, OutlinedInput, Box,Select,CardActions,Button,Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Rating from 'material-ui-rating'

import CreateIcon from '@material-ui/icons/Create';
import DeleteIcon from '@material-ui/icons/Delete';
import SaveIcon from '@material-ui/icons/Save';
import Close from '@material-ui/icons/Close';
import AccountBox from '@material-ui/icons/AccountBox';
import AddBox from '@material-ui/icons/AddBox';

import Table from '@material-ui/core/Table';
import TableFooter from '@material-ui/core/TableFooter';
import TableRow from '@material-ui/core/TableRow';

import TablePagination from '@material-ui/core/TablePagination';
import $ from "jquery";

import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';




import ApiService from "../../ApiService";

import '../css/productDetails.css';



const style ={
    display: 'flex',
    justifyContent: 'center'
}

class ProductDetails extends Component {

    constructor(props) {
        super(props)
        this.state = {
            products:[],
            message:'',
            visible:'none',
            show:false,
            error:false,
            deleteProductId:'',

            pageSize:20,
            pageNo:0,
            Current_page_no:0,
            Total_no_of_pages:0,
            Total_no_of_elements:0,
            nxtDisabled:false,
            prwDisabled:true,
        }
        // this.deleteProduct = this.deleteProduct.bind(this);
        // this.editProduct = this.editProduct.bind(this);
        // this.addItem = this.addItem.bind(this);
        // this.reloadUserList = this.reloadUserList.bind(this);
    }

    componentDidMount() {
        this.reloadProductsList();
    }

    reloadProductsList = () => {
        ApiService.getAllProducts(this.state.pageNo,this.state.pageSize)
            .then((res) => {
                let current_page = res.data.Current_page_no;
                let total_no_of_pages = res.data.Total_no_of_pages;
                let total_no_of_elements = res.data.Total_no_of_elements;
                let products = res.data.data;
                this.setState({
                    Current_page_no:res.data.Current_page_no,
                    Total_no_of_pages:res.data.Total_no_of_pages,
                    Total_no_of_elements:res.data.Total_no_of_elements,
                })
                      {products.map(product =>(
                          ApiService.getShopById(product.shopId)
                              .then((res) => {
                                  let shops = res.data;
                                    this.setState(prevState => ({
                                      products: [...prevState.products, {
                                        "productId":product.productId,
                                        "shopId":product.shopId,
                                        "shopName":shops.shopName,
                                        "title":product.title,
                                        "description":product.description,
                                        "category":product.category,
                                        "lastPrice":product.lastPrice,
                                        "sellPrice":product.sellPrice,
                                        "warranty":product.warranty,
                                        "rating":product.rating,
                                        "stock":product.stock,
                                        "brand":product.brand,
                                        "model":product.model,

                                        "image1":product.image1,
                                        "image2":product.image2,
                                        "image3":product.image3,
                                        "image4":product.image4,
                                        "image5":product.image5,
                                      }]
                                    }))


                              })
                      ))}

            });
    }




    addItem = () => {
        // window.localStorage.removeItem("productId");
        this.props.history.push('/addItem');
    }



    handleImgChange=(e,imgNo,imgBtn) =>{
      //  this.setState({[e.target.name]:e.target.value,})
        //if([e.target.name] == [showImgId.target.name]){


             // var al = document.getElementById(imgNo).name;
             // var className = $('.'+imgNo).prop('name');
             //
             //
             // $("#productImg1").css('border','0px solid black');
             // $("#productImg2").css('border','0px solid black');
             // $("#productImg3").css('border','0px solid black');
             // $("#productImg4").css('border','0px solid black');
             // $("#productImg5").css('border','0px solid black');
             //
             // $("#productImg1").css('display','none');
             // $("#productImg2").css('display','none');
             // $("#productImg3").css('display','none');
             // $("#productImg4").css('display','none');
             // $("#productImg5").css('display','none');
             //
             // $('.'+[e.target.name]).css('border','3px solid red');
             // $('.'+[e.target.name]).css('display','block');
             //if([e.target.name] == )

        //}
      if(imgBtn=='listImg1'){
          this.setState({
            viewImg1:'block',

            viewImg2:'none',
            viewImg3:'none',
            viewImg4:'none',
            viewImg5:'none',



            imgBtnBorder1:'1px solid black',

            imgBtnBorder2:'none',
            imgBtnBorder3:'none',
            imgBtnBorder4:'none',
            imgBtnBorder5:'none',
          });
      }else if (imgBtn=='listImg2'){
        this.setState({
          viewImg2:'block',

          viewImg1:'none',
          viewImg3:'none',
          viewImg4:'none',
          viewImg5:'none',


          imgBtnBorder2:'1px solid black',

          imgBtnBorder1:'none',
          imgBtnBorder3:'none',
          imgBtnBorder4:'none',
          imgBtnBorder5:'none',
        });
      }
      else if (imgBtn=='listImg3'){
        this.setState({
          viewImg3:'block',

          viewImg1:'none',
          viewImg2:'none',
          viewImg4:'none',
          viewImg5:'none',


          imgBtnBorder3:'1px solid black',

          imgBtnBorder2:'none',
          imgBtnBorder1:'none',
          imgBtnBorder4:'none',
          imgBtnBorder5:'none',
        });
      }
      else if (imgBtn=='listImg4'){
        this.setState({
          viewImg4:'block',

          viewImg1:'none',
          viewImg2:'none',
          viewImg3:'none',
          viewImg5:'none',


          imgBtnBorder4:'1px solid black',

          imgBtnBorder2:'none',
          imgBtnBorder3:'none',
          imgBtnBorder1:'none',
          imgBtnBorder5:'none',
        });
      }
      else if (imgBtn=='listImg5'){
        this.setState({
          viewImg5:'block',

          viewImg1:'none',
          viewImg2:'none',
          viewImg3:'none',
          viewImg4:'none',


          imgBtnBorder5:'1px solid black',

          imgBtnBorder2:'none',
          imgBtnBorder3:'none',
          imgBtnBorder4:'none',
          imgBtnBorder1:'none',
        });
      }
    }



    deleteProduct = (productId) => {
      this.setState({
          visible:'block',
          show:true,
          error:false,
          deleteProductId:`${productId}`,
      })
    }

    handlecoverHide=(e)=>{
      this.setState({
        visible:'none',
        show:false,
        error:false,
        message:'',
      })
    }

    conformDeleteProduct = () => {
        ApiService.deleteProduct(this.state.deleteProductId)
           .then(res => {
               this.setState({message : 'Product deleted successfully.',show:false,error:false,});
               this.setState({products: this.state.products.filter(product => product.productId !== this.state.deleteProductId)})
               setTimeout(() => {
                  this.setState({message:'',visible:'none'});
               },1500)
           })
           .catch((err) => {
              this.setState({error:true,show:false});
              setTimeout(() => {
                  this.setState({error:false,show:false,visible:'none',});
              },1500);
           })
    }



    next = () => {
      if(this.state.Total_no_of_pages-1 > this.state.pageNo){
        this.setState({
          pageNo:this.state.pageNo+1,
          nxtDisabled:false,
          prwDisabled:false,

        })
        setTimeout(() => {
              {this.reloadProductsList()}
        },500);
      }else {
        this.setState({
          nxtDisabled:true,
        })
      }
    }



    preview = () => {
      if(this.state.Current_page_no > 0){
          this.setState({
              pageNo:this.state.pageNo-1,
              prwDisabled:false,
              nxtDisabled:false,

          })
          setTimeout(() => {
                {this.reloadProductsList()}
          },500);
      }else {
          this.setState({
            prwDisabled:true,
          })
        }
    }




    render() {
      const products=this.state.products

        return (
            <div style={{width:'90%',margin:'auto',  marginTop:'50px',}}>
              <Box style={{width:'100%',backgroundColor:'white' ,height:'150px'}}>
                <Typography variant="h4" style={{display: 'flex',justifyContent: 'center',position:'relative',top:'20px'}}>Product Details</Typography>
                <Button variant="contained" style={{backgroundColor:'#03a9f4',color:'white',float:'right',marginRight:'30px',fontWeight:'bold',marginTop:'20px'}} onClick={() => this.addItem()}><AddBox style={{marginRight:'5px'}}/>
                    Add Item
                </Button>
                <Typography variant="p" style={{float:'left',marginLeft:'30px',position:'relative',top:'70px'}}>Total results {this.state.Total_no_of_elements}</Typography>
              </Box>


                <Grid container>
                {
                    products.map(product =>(
                          <Grid item md={12} style={{marginTop:'20px'}}  >

                              <Card  key={product.productId}  elevation={5}>
                              <br/><br/>
                                <Grid container>
                                    <Grid item item xs={12} sm={12} md={6} lg={6}>


                                          <Paper id='productImgBox' elevation={3}>
                                                <CardMedia
                                                  Id='productImg1'
                                                  className='productImg1'
                                                  component="img"
                                                  image={product.image1}
                                                  class={product.productId}
                                                  style={{display:this.state.viewImg1}}

                                                />
                                                <CardMedia
                                                  Id='productImg2'
                                                  component="img"
                                                  image={product.image2}
                                                  class={product.productId}
                                                  style={{display:this.state.viewImg2}}
                                                />
                                                <CardMedia
                                                  Id='productImg3'
                                                  component="img"
                                                  image={product.image3}
                                                  class={product.productId}
                                                  style={{display:this.state.viewImg3}}
                                                />
                                                <CardMedia
                                                  Id='productImg4'
                                                  component="img"
                                                  image={product.image4}
                                                  class={product.productId}
                                                  style={{display:this.state.viewImg4}}
                                                />
                                                <CardMedia
                                                  Id='productImg5'
                                                  component="img"
                                                  image={product.image5}
                                                  class={product.productId}
                                                  style={{display:this.state.viewImg5}}
                                                />
                                          </Paper>
                                          <Paper id="imgListBox" elevation={4}>
                                            <Button id="imgBtn1" name={product.productId} onClick={(e) => this.handleImgChange(e,"productImg1","listImg1")}   style={{border:this.state.imgBtnBorder1}}>
                                              <CardMedia
                                                Id='listImg1'
                                                component="img"
                                                image={product.image1}
                                                name={product.productId}
                                                class="img-responsive"

                                              />
                                            </Button>
                                            <Button id="imgBtn2"  name={product.productId}  onClick={(e) => this.handleImgChange(e,"productImg2","listImg2")} style={{border:this.state.imgBtnBorder2}}>
                                              <CardMedia
                                                Id='listImg2'
                                                component="img"
                                                image={product.image2}
                                                name={product.productId}
                                                class="img-responsive"

                                              />
                                            </Button>
                                            <Button id="imgBtn3"  name={product.productId}   onClick={(e) => this.handleImgChange(e,"productImg3","listImg3")} style={{border:this.state.imgBtnBorder3}}>
                                              <CardMedia
                                                Id='listImg3'
                                                component="img"
                                                image={product.image3}
                                                name={product.productId}
                                                class="img-responsive"

                                              />
                                            </Button>
                                            <Button id="imgBtn4"  name={product.productId}  onClick={(e) => this.handleImgChange(e,"productImg4","listImg4")} style={{border:this.state.imgBtnBorder4}}>
                                              <CardMedia
                                                Id='listImg4'
                                                component="img"
                                                image={product.image4}
                                                name={product.productId}
                                                class="img-responsive"

                                              />
                                            </Button>
                                            <Button id="imgBtn5"  name={product.productId}  onClick={(e) => this.handleImgChange(e,"productImg5","listImg5")} style={{border:this.state.imgBtnBorder5}}>
                                              <CardMedia
                                                Id='listImg5'
                                                component="img"
                                                image={product.image5}
                                                name={product.productId}
                                                title="Contemplative Reptile"
                                                class="img-responsive"

                                              />
                                            </Button>
                                          </Paper>




                                      </Grid>


                                      <Grid item item xs={12} sm={12} md={6} lg={6}>
                                        <Paper id="adminProductDetailsInfo" elevation={3}>
                                          <CardContent>
                                                <Typography gutterBottom   id='productTitlePD'>
                                                    Title :- {product.title}
                                                </Typography>

                                                <Typography gutterBottom   id='productTitlePD'>
                                                    Shop :- {product.shopName}
                                                </Typography>

                                                <Typography gutterBottom   id='productTitlePD'>
                                                    Brand :- {product.brand}
                                                </Typography>

                                                <Typography gutterBottom   id='productTitlePD'>
                                                    Model :- {product.model}
                                                </Typography>

                                                <Typography gutterBottom   id='productTitlePD'>
                                                    Category :- {product.category}
                                                </Typography>

                                                <Typography gutterBottom   id='productTitlePD'>
                                                    Stock :- {product.stock}
                                                </Typography>

                                                <Typography id='lastPrice' variant="h6">
                                                    Last Price :- {product.lastPrice}
                                                </Typography>

                                                <Typography id='salePrice' variant="h6">
                                                    Sale Price :-  {product.sellPrice}
                                                </Typography>

                                                <Typography id='offerPrice'>
                                                    Rating :- {product.rating} Stars
                                                </Typography>

                                                <Typography id='warranty'>
                                                    Warranty :- {product.warranty} Months
                                                </Typography>

                                                <Typography gutterBottom   id='productTitlePD'>
                                                Description :- {product.description}
                                                </Typography>

                                          </CardContent>

                                          <Box style={{float:'right',marginRight:'30px', width:'250px',marginTop:'90px'}} >
                                              <Button variant="contained" id="editBtn" style={{backgroundColor:'#03a9f4',color:'white',margin:'auto',fontWeight:'bold'}} href={'/editProduct/'+product.productId} ><CreateIcon style={{marginRight:'5px'}}/>
                                              Edit
                                              </Button>
                                              <Button variant="contained" id="deleteBtn" style={{backgroundColor:'#03a9f4',color:'white',margin:'auto',fontWeight:'bold'}} onClick={() => this.deleteProduct(product.productId)} ><DeleteIcon style={{marginRight:'5px'}}/>
                                              Delete
                                              </Button>
                                          </Box>


                                          </Paper>

                                      </Grid>
                                  </Grid>
                                  <br/><br/>
                              </Card>


                          </Grid>
                    ))
                }

                      <Grid item xs={12} sm={12} md={12} lg={12}>
                          <Paper style={{width:'100%',height:'60px',marginTop:'30px'}}>
                                <Box style={{position:'relative',top:'10px',height:'40px',width:'265px',backgroundColor:'red',margin:'auto'}}>


                                  <Button disabled={this.state.prwDisabled} onClick={()=>this.preview()} style={{float:'left' ,backgroundColor:'#03a9f4',color:'black',fontWeight:'bold',marginRight:'10px',height:'40px',color:'white'}}  >preview</Button>
                                        <Typography style={{float:'left',color:'black',fontWeight:'bold',marginRight:'10px',marginTop:'5px',backgroundColor:'green',width:'60px',textAlign:'center'}} variant='h6'>{this.state.Current_page_no+1}</Typography>
                                  <Button disabled={this.state.nxtDisabled} onClick={()=>this.next()}  style={{float:'right',backgroundColor:'#03a9f4',color:'black',fontWeight:'bold',width:'100px',height:'40px',color:'white'}}>Next</Button>


                                </Box>
                          </Paper>
                      </Grid>
                </Grid>





                <Box style={{display:this.state.visible,position: 'fixed',top: '0px',left:'0px',width:'100%',height:'100%',zIndex:'2', backgroundColor:'black',opacity:'0.8'}}  onClick={() => this.handlecoverHide()}></Box>

                    {this.state.show&&(
                      <Alert variant="filled" severity="warning" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '3',left: `${window.innerWidth/2-275}px`,color:'white'}}
                            action={
                                <Box style={{marginTop:'50px'}}>
                                  <Button color="inherit" size="small" style={{fontSize:'14px'}} onClick={() => this.handlecoverHide()} >
                                    Cancel
                                  </Button>
                                  <Button color="inherit" size="small" style={{fontSize:'14px'}} onClick={() => this.conformDeleteProduct()} >
                                    Delete
                                  </Button>
                                </Box>
                              }
                      >
                            <AlertTitle>Warning</AlertTitle>
                            Are you sure delete this product?

                      </Alert>
                    )}
                    {this.state.message&&(
                      <Alert variant="filled" severity="success" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '3',left: `${window.innerWidth/2-275}px`,backgroundColor:'green',color:'white'}}>
                            <AlertTitle>success</AlertTitle>
                            {this.state.message}
                      </Alert>
                    )}
                    {this.state.error&&(
                      <Alert variant="filled" severity="error" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '5',left: `${window.innerWidth/2-275}px`,color:'white'}}>
                            <AlertTitle>Failed!</AlertTitle>
                            user delete failed
                      </Alert>
                    )}





            </div>
        );
    }

}

export default ProductDetails;
