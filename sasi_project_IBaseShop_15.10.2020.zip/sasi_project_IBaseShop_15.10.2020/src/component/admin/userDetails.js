import React, { Component } from 'react'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Button from '@material-ui/core/Button';
import CreateIcon from '@material-ui/icons/Create';
import DeleteIcon from '@material-ui/icons/Delete';
import Close from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';
import Box from '@material-ui/core/Box';
import Paper from '@material-ui/core/Paper';

import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';


import ApiService from "../../ApiService";


const style ={
    display: 'flex',
    justifyContent: 'center'
}

class UserDetails extends Component {

    constructor(props) {
        super(props)
        this.state = {
            users: [],
            message: '',
            pageSize:20,
            pageNo:0,
            Total_no_of_pages:0,
            Total_no_of_elements:0,
            Current_page_no:0,
            nxtDisabled:false,
            prwDisabled:true,

            visible:'none',
            deleteUserId:'',
            show:false,
            error:false,
        }

    }

    componentDidMount() {
        this.reloadUserList();
        // const message = this.props.location.message;
       // if(message != undefined){
       //      this.messageView(message);
       // }

    }

    reloadUserList = () => {
        ApiService.getAllUsers(this.state.pageSize,this.state.pageNo)
        .then((res) => {
            this.setState({
              users: res.data.data,
              Total_no_of_pages:res.data.Total_no_of_pages,
              Total_no_of_elements:res.data.Total_no_of_elements,
              Current_page_no:res.data.Current_page_no,
            })
        });
    }

    // messageView = (message) => {
    //     alert(message)
    // }

    deleteUser = (userId) => {
      this.setState({
          visible:'block',
          show:true,
          deleteUserId:`${userId}`,
          error:false,
      })
    }
    handlecoverHide=(e)=>{
      this.setState({
        visible:'none',
        show:false,
        error:false,
        message:'',
      })
    }


    conformDeleteProduct = () =>{
        ApiService.deleteUserById(this.state.deleteUserId)
           .then(res => {
               this.setState({message : 'User deleted successfully.',show:false,error:false});
               this.setState({users: this.state.users.filter(users => users.userId !== this.state.deleteUserId)})
               setTimeout(() => {
                  this.setState({message:'',visible:'none'});
               },1500)
           })
           .catch((err) => {
              this.setState({error:true,show:false});
              setTimeout(() => {
                  this.setState({error:false,show:false,visible:'none',});
              },1500);
           })
        // this.setState({message:'Shop deleted successfully.',show:false,});
        // this.setState({users: this.state.users.filter(users => users.userId !== this.state.deleteUserId)});



    }









    next = () => {
      if(this.state.Total_no_of_pages-1 > this.state.pageNo){
        this.setState({
          pageNo:this.state.pageNo+1,
          nxtDisabled:false,
          prwDisabled:false,
        })
        setTimeout(() => {
              {this.reloadUserList()}
        },500);
      }else {
        this.setState({
          nxtDisabled:true,
        })
      }
    }

    preview = () => {
      if(this.state.Current_page_no > 0){
          this.setState({
              pageNo:this.state.pageNo-1,
              prwDisabled:false,
              nxtDisabled:false,
          })
          setTimeout(() => {
                {this.reloadUserList()}
          },500);
      }else {
          this.setState({
            prwDisabled:true,
          })
        }
    }


    render() {
      const users = this.state.users;
        return (
            <div style={{width:'90%',margin:'auto', backgroundColor:'white' , marginTop:'50px',}}>
                <Typography variant="h4" style={style}>User Details</Typography>
                {/*<Button variant="contained" style={{backgroundColor:'#03a9f4',color:'white',float:'right',marginRight:'30px'}} onClick={() => this.addUser()}>
                    Add User
                </Button>*/}
                <Typography variant="p" style={{marginLeft:'30px',fontSize:'14px'}}>{this.state.Total_no_of_elements} results</Typography>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Id</TableCell>
                            <TableCell align="left">UserName</TableCell>
                            <TableCell align="left">FirstName</TableCell>
                            <TableCell align="left">LastName</TableCell>
                            <TableCell align="left">Phone</TableCell>
                            <TableCell align="left">Email</TableCell>
                            <TableCell align="left">Address</TableCell>
                            <TableCell align="left">Rols</TableCell>


                        </TableRow>
                    </TableHead>
                    <TableBody>

                        {users.map(row => (
                            <TableRow key={row.userId}>
                                <TableCell component="th" scope="row">
                                    {row.userId}
                                </TableCell>
                                <TableCell align="left">{row.userName}</TableCell>
                                <TableCell align="left">{row.firstName}</TableCell>
                                <TableCell align="left">{row.lastName}</TableCell>
                                <TableCell align="left">{row.phoneNumber}</TableCell>
                                <TableCell align="left">{row.email}</TableCell>
                                <TableCell align="left">{row.address}</TableCell>
                                <TableCell align="left">{row.roles.map(row2=>(
                                  <TableRow key={row2.id}>

                                      <TableCell align="left">{row2.name}</TableCell>
                                  </TableRow>
                                ))}</TableCell>

                              <TableCell align="left" ><Button href={"/editUser/"+row.userId} ><CreateIcon /></Button></TableCell>
                                <TableCell align="left" onClick={() => this.deleteUser(row.userId)}><Button><DeleteIcon /></Button></TableCell>

                            </TableRow>
                        ))}

                    </TableBody>
                </Table>

                <Box style={{width:'250px',height:'100px',margin:'auto',marginTop:'50px'}}>

                    <Button disabled={this.state.prwDisabled} onClick={()=>this.preview()} style={{float:'left', backgroundColor:'#03a9f4',color:'black',fontWeight:'bold',marginRight:'20px',height:'40px'}}  >preview</Button>  <Button></Button>
                          <Typography style={{float:'left',color:'black',fontWeight:'bold',marginRight:'20px'}} variant='h6'>{this.state.Current_page_no+1}</Typography>
                    <Button disabled={this.state.nxtDisabled} onClick={()=>this.next()}  style={{float:'left',marginTop:'-18px',backgroundColor:'#03a9f4',color:'black',fontWeight:'bold',width:'100px',height:'40px'}}>Next</Button>

                </Box>


                <Box style={{display:this.state.visible,position: 'fixed',top: '0px',left:'0px',width:'100%',height:'100%',zIndex:'2', backgroundColor:'black',opacity:'0.8'}}  onClick={() => this.handlecoverHide()}></Box>
                {this.state.show&&(
                  <Alert variant="filled" severity="warning" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '3',left: `${window.innerWidth/2-275}px`,color:'white'}}
                        action={
                            <Box style={{marginTop:'50px'}}>
                              <Button color="inherit" size="small" style={{fontSize:'14px'}} onClick={() => this.handlecoverHide()} >
                                Cancel
                              </Button>
                              <Button color="inherit" size="small" style={{fontSize:'14px'}} onClick={() => this.conformDeleteProduct()} >
                                Delete
                              </Button>
                            </Box>
                          }
                  >
                        <AlertTitle>Warning</AlertTitle>
                        Are you sure delete this product?

                  </Alert>
                )}
                {this.state.message&&(
                  <Alert variant="filled" severity="success" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '4',left: `${window.innerWidth/2-275}px`,backgroundColor:'green',color:'white'}}>
                        <AlertTitle>success</AlertTitle>
                        {this.state.message}
                  </Alert>
                )}
                {this.state.error&&(
                  <Alert variant="filled" severity="error" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '5',left: `${window.innerWidth/2-275}px`,color:'white'}}>
                        <AlertTitle>Failed!</AlertTitle>
                        user delete failed
                  </Alert>
                )}

                <br/><br/><br/>
            </div>
        );
    }

}

export default UserDetails;
