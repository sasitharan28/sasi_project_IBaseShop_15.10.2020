import React, { Component } from 'react'
import { Card, CardContent, Grid, FormControl, TextField, Input, FormHelperText, OutlinedInput ,Select } from '@material-ui/core';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton ,Divider,Box } from "@material-ui/core";
import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';

import ApiService from "../../ApiService";

import '../css/editOrder.css';

const style ={
  float:'right',
  marginRight:'50px',
  marginTop:'30px',
}

class EditOrder extends Component {

    constructor(props){
        super(props);
        this.state ={
          orderId:'',
          userId:'',
          orderDateTime:'',
          totalPrice:'',

          buyProductDetails:[],
          length:'',

          userName:'',
          email:'',
          phoneNumber:'',
          address:'',

          userDetailEdit:false,
          buyProductDetailEdit:'',
        }
        // this.saveUser = this.saveUser.bind(this);
        // this.loadUser = this.loadUser.bind(this);
    }

    componentDidMount() {
        const orderId = this.props.match.params.id;
        this.loadOrder(orderId);
    }

    loadOrder = (orderId) => {
        ApiService.getOrderById(orderId)
            .then((res) => {
                let order = res.data;
                this.setState({
                    orderId:order.orderId,
                    userId:order.userId,
                    orderDateTime:order.orderDateTime,
                    totalPrice:order.totalPrice,
                    buyProductDetails:order.buyProductDetails,
                })
                this.loadUser(order.userId)
                this.buyProductDetailsInfo(order.buyProductDetails);
            });
    }


    loadUser = (userId) => {
      ApiService.getUserById(userId)
          .then((res) => {
              let user = res.data;
              this.setState({
                  userId:user.userId,
                  email:user.email,
                  userName:user.userName,
                  phoneNumber:user.phoneNumber,
                  address:user.address,
              })
          })
    }


    buyProductDetailsInfo = (buyProductDetails) => {
        this.setState({
            length:buyProductDetails.length,
        })
        // {buyProductDetails.map((row,index) => (
        //     this.state = {
        //           productId:''
        //     }
        // ))}

    }



    onChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
      }

    onChangeProDetail = (e) => {

    }

    updateOrder = (e) => {
        e.preventDefault();
        let order = {
          id: this.state.id,
          username: this.state.username,
          productId: this.state.productId,
          time: this.state.time,
          date: this.state.date,
          price: this.state.price,
          quantity: this.state.quantity,
          email: this.state.email,
          phone:this.state.phone,
          address: this.state.address
        };
        ApiService.editOrder(order)
            .then(res => {
                this.setState({message : 'User added successfully.'});
                this.props.history.push('/orderDetails');
            });
    }



    editBuyProductDetail = (buyProductId) => {
          this.setState({buyProductDetailEdit:buyProductId})
    }




    render() {

      // const st = {!this.state.buyProductDetailEdit&&(
      //   <li>on list</li>
      // )};




        return (
            <div>
            <Paper className='orderEditeWarraper' elevation={1}>
              <Typography id="profileHeading">Edit Order</Typography>


                    <Paper elevation={5} style={{width:'90%',margin:'auto',marginTop:'40px'}}>

                        <Grid container id="profileGrid">

                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="userNameDiv" elevation={3}>
                                <Typography variant="h6" id="userNameDivTitle">Order Id</Typography>
                                <Typography variant="h5" id="userNameLabel">{this.state.orderId}</Typography>
                            </Paper>
                          </Grid>


                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="userNameDiv" elevation={3}>
                                <Typography variant="h6" id="userNameDivTitle">User name</Typography>
                                <Typography variant="h5" id="userNameLabel">{this.state.userName}</Typography>
                            </Paper>
                          </Grid>



                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="phoneDiv" elevation={3}>
                                <Box id="phonebox">
                                    <Typography variant="h6" id="lastNameDivTitle">Phone Number</Typography>
                                        <FormControl variant="outlined" id='emailIp'>
                                            <InputLabel htmlFor="component-outlined">Phone</InputLabel>
                                            <OutlinedInput
                                                id="component-outlined"
                                                value={this.state.phoneNumber}
                                                onChange={this.onChange}
                                                label="Phone"
                                                type="Number"
                                                name="phoneNumber"
                                            />
                                        </FormControl>
                                </Box>
                            </Paper>
                          </Grid>


                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="emailDiv" elevation={3}>
                                <Box id="emailbox">
                                    <Typography variant="h6" id="emailDivTitle">Email</Typography>
                                        <FormControl variant="outlined" id='emailIp'>
                                            <InputLabel htmlFor="component-outlined">Email</InputLabel>
                                            <OutlinedInput
                                                id="component-outlined"
                                                value={this.state.email}
                                                onChange={this.onChange}
                                                label="Email"
                                                name="email"
                                            />
                                        </FormControl>
                                </Box>
                            </Paper>
                          </Grid>



                          <Grid item xs={12} sm={12} md={6}>
                            <Paper id="addressDiv" elevation={3}>
                                <Box id="addressbox">
                                    <Typography variant="h6" id="lastNameDivTitle">Address</Typography>
                                        <FormControl variant="outlined" id='emailIp'>
                                            <InputLabel htmlFor="component-outlined">Address</InputLabel>
                                            <OutlinedInput
                                                id="component-outlined"
                                                value={this.state.address}
                                                onChange={this.onChange}
                                                label="Address"
                                                name="address"
                                            />
                                        </FormControl>
                                </Box>
                            </Paper>
                          </Grid>

                      </Grid>

                    </Paper>





                      {this.state.buyProductDetails.map((row,index )=> (
                        <Paper elevation={5} style={{width:'90%',margin:'auto',marginTop:'40px'}}>
                        <Grid container>
                              

                                    <Grid item xs={12} sm={12} md={6}>
                                        <Paper id="emailDiv" elevation={3}>
                                            <Box id="emailbox">
                                                <Typography variant="h6" id="emailDivTitle">product Id</Typography>
                                                    <FormControl variant="outlined" id='emailIp'>
                                                        <InputLabel htmlFor="component-outlined">product Id</InputLabel>
                                                        <OutlinedInput
                                                            id="component-outlined"
                                                            value={row.buyProductId}
                                                            onChange={this.onChange}
                                                            label="Product Id"
                                                            type=''
                                                            name=""
                                                        />
                                                    </FormControl>
                                            </Box>
                                        </Paper>
                                    </Grid>

                                    <Grid item xs={12} sm={12} md={6}>
                                        <Paper id="emailDiv" elevation={3}>
                                            <Box id="emailbox">
                                                <Typography variant="h6" id="emailDivTitle">Shop Id</Typography>
                                                <Typography variant="h5" id="userNameLabel">{row.shopId}</Typography>
                                            </Box>
                                        </Paper>
                                    </Grid>

                                    <Grid item xs={12} sm={12} md={6}>
                                        <Paper id="emailDiv" elevation={3}>
                                            <Box id="emailbox">
                                                <Typography variant="h6" id="emailDivTitle">Quantity</Typography>
                                                    <FormControl variant="outlined" id='emailIp'>
                                                        <InputLabel htmlFor="component-outlined">Quantity</InputLabel>
                                                        <OutlinedInput
                                                            id="component-outlined"
                                                            value={row.quantity}
                                                            onChange={this.onChange}
                                                            label="Quantity"
                                                            type=''
                                                            name=""
                                                        />
                                                    </FormControl>
                                            </Box>
                                        </Paper>
                                    </Grid>

                                    <Grid item xs={12} sm={12} md={6}>
                                        <Paper id="emailDiv" elevation={3}>
                                            <Box id="emailbox">
                                                <Typography variant="h6" id="emailDivTitle">price</Typography>
                                                    <FormControl variant="outlined" id='emailIp'>
                                                        <InputLabel htmlFor="component-outlined">price</InputLabel>
                                                        <OutlinedInput
                                                            id="component-outlined"
                                                            value={row.price}
                                                            onChange={this.onChange}
                                                            label="Quantity"
                                                            type=''
                                                            name=""
                                                        />
                                                    </FormControl>
                                            </Box>
                                        </Paper>
                                    </Grid>


                                <Grid item xs={12}>
                                    <Box>
                                        <Button onClick={() => this.editBuyProductDetail(row.buyProductId)}>edit</Button>
                                    </Box>
                                </Grid>

                        </Grid>
                        </Paper>
                      ))}







                    <Grid container>
                      <Grid item xs={12} sm={12} >
                          <Box style={style}>
                            <Button onClick={this.updateOrder} style={{backgroundColor:'white',fontWeight:'bold',backgroundColor:'#03a9f4',color:'white'}}>Update</Button>
                          </Box>
                      </Grid>
                    </Grid>






                <br/><br/>



            </Paper>
            </div>
        );
    }
}

export default EditOrder;
