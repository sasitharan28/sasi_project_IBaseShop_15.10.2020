import React, { Component } from 'react'

import ApiService from "./../ApiService";
export const DataContext = React.createContext();
//

export class Data extends Component {
  constructor(props){
    super(props)
    this.state={
      products:[],
      cart: [],
      total: 0,
      payment:[],
      cartNo:0,
      tt:["st","tt","rt","vt"],
    }
  }

    // state = {
    //
    // products: [
    //
    //             {
    //                 "_id": "1",
    //                 "title": "I phone 123",
    //                 "src1": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src2": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src3": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src4": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src5": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "description": "phone phone phone phone phone phone ",
    //                 "lastPrice":135000,
    //                 "sellPrice":120000,
    //                 "count": 1,
    //                 "brand":"Apple",
    //                 "model": "S10",
    //                 "warandy":5,
    //                 "rating":3,
    //             },
    //             {
    //                 "_id": "2",
    //                 "title": "ear phone",
    //                 "src1": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src2": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src3": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src4": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src5": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "description": "ear phone ear phone ear phone ear phone ",
    //                 "lastPrice":1500,
    //                 "sellPrice":1200,
    //                 "count": 1,
    //                 "brand":"BB",
    //                 "model": "S10",
    //                 "warandy":24,
    //                 "rating":3,
    //             },
    //             {
    //                 "_id": "3",
    //                 "title": "I phone S10",
    //                 "src1": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src2": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src3": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src4": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src5": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "description": "phone phone phone phone phone phone ",
    //                 "lastPrice":90000,
    //                 "sellPrice":83000,
    //                 "count": 1,
    //                 "brand":"I phone",
    //                 "model": "S10",
    //                 "warandy":12,
    //                 "rating":3,
    //             },
    //             {
    //                 "_id": "4",
    //                 "title": "mi ear phone",
    //                 "src1": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src2": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src3": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src4": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src5": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "description": "ear phone ear phone ear phone ear phone",
    //                 "lastPrice":900,
    //                 "sellPrice":800,
    //                 "count": 1,
    //                 "brand":"I phone",
    //                 "model": "twist",
    //                 "warandy":18,
    //                 "rating":3,
    //             },
    //             {
    //                 "_id": "5",
    //                 "title": "I phone v1",
    //                 "src1": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src2": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src3": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src4": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src5": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "description": "phone phone phone phone phone phone ",
    //                 "lastPrice":65000,
    //                 "sellPrice":60000,
    //                 "count": 1,
    //                 "brand":"I phone",
    //                 "model": "S10",
    //                 "warandy":6,
    //                 "rating":3,
    //             },
    //             {
    //                 "_id": "6",
    //                 "title": "samsung ear phone",
    //                 "src1": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src2": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src3": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src4": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src5": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "description": "ear phone ear phone ear phone ear phone",
    //                 "lastPrice":1100,
    //                 "sellPrice":700,
    //                 "count": 1,
    //                 "brand":"BBBB",
    //                 "model": "S10",
    //                 "warandy":24,
    //                 "rating":3,
    //             },
    //             {
    //                 "_id": "7",
    //                 "title": "iphone ear phone",
    //                 "src1": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src2": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src3": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src4": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "src5": "https://image.shutterstock.com/image-photo/new-white-headphones-on-dark-600w-1709709055.jpg",
    //                 "description": "ear phone ear phone ear phone ear phone",
    //                 "lastPrice":3600,
    //                 "sellPrice":3000,
    //                 "count": 1,
    //                 "brand":"BBBB",
    //                 "model": "S10",
    //                 "warandy":22,
    //                 "rating":3,
    //             },
    //             {
    //                 "_id": "5",
    //                 "title": "I phone x11",
    //                 "src1": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src2": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src3": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src4": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "src5": "https://images.unsplash.com/photo-1555375771-14b2a63968a9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=658&q=80",
    //                 "description": "phone phone phone phone phone phone ",
    //                 "lastPrice":98000,
    //                 "sellPrice":86000,
    //                 "count": 1,
    //                 "brand":"I phone",
    //                 "model": "S10",
    //                 "warandy":8,
    //                 "rating":3,
    //             },{
    //               "id":'phone1',
    //               "title":'Apple iphone 11',
    //               "src1":'https://pbs.twimg.com/media/EhBF69tU8AA30rM?format=jpg&name=small',
    //               "src2":'https://pbs.twimg.com/media/EhBF69tU8AA30rM?format=jpg&name=small',
    //               "src3":'https://pbs.twimg.com/media/EhBF69tU8AA30rM?format=jpg&name=small',
    //               "src4":'https://pbs.twimg.com/media/EhBF69tU8AA30rM?format=jpg&name=small',
    //               "src5":'https://pbs.twimg.com/media/EhBF69tU8AA30rM?format=jpg&name=small',
    //               "description": "phone phone phone phone phone phone ",
    //               "lastPrice":135000,
    //               "sellPrice":120000,
    //               "count": 1,
    //               "brand":"I phone",
    //               "model": "S10",
    //               "warandy":12,
    //               "rating":4,
    //             },{
    //               "id":'phone2',
    //               "title":'sumsung galaxy j2',
    //               "src1":'https://pbs.twimg.com/media/EhCtnLdU0AACxPE?format=jpg&name=360x360',
    //               "src2":'https://pbs.twimg.com/media/EhCtnLdU0AACxPE?format=jpg&name=360x360',
    //               "src3":'https://pbs.twimg.com/media/EhCtnLdU0AACxPE?format=jpg&name=360x360',
    //               "src4":'https://pbs.twimg.com/media/EhCtnLdU0AACxPE?format=jpg&name=360x360',
    //               "src5":'https://pbs.twimg.com/media/EhCtnLdU0AACxPE?format=jpg&name=360x360',
    //               "description": "phone phone phone phone phone phone ",
    //               "lastPrice":18500,
    //               "sellPrice":15000,
    //               "count": 1,
    //               "brand":"BBBB",
    //               "model": "S10",
    //               "warandy":12,
    //               "rating":2,
    //             },{
    //               "id":'phone3',
    //               "title":'One Plus black sheep killer',
    //               "src1":'https://pbs.twimg.com/media/Egwzx1bVgAkM2xc?format=jpg&name=small',
    //               "src2":'https://pbs.twimg.com/media/Egwzx1bVgAkM2xc?format=jpg&name=small',
    //               "src3":'https://pbs.twimg.com/media/Egwzx1bVgAkM2xc?format=jpg&name=small',
    //               "src4":'https://pbs.twimg.com/media/Egwzx1bVgAkM2xc?format=jpg&name=small',
    //               "src5":'https://pbs.twimg.com/media/Egwzx1bVgAkM2xc?format=jpg&name=small',
    //               "description": "phone phone phone phone phone phone ",
    //               "lastPrice":13500,
    //               "sellPrice":12000,
    //               "count": 1,
    //               "brand":"BBBB",
    //               "model": "S10",
    //               "warandy":6,
    //               "rating":3,
    //             }
    // ],
    //     cart: [],
    //     total: 0,
    //     payment:[]
    // };

    addCart = (id) =>{
        const {cart} = this.state;
        const check = cart.every(item =>{
            return item.productId !== id
        })
        if(check){
            // const data = products.filter(product =>{
            //     return product.productId === id
            // })
            ApiService.getProductById(id)
            .then(res =>{
                const data = res.data;

                this.setState(prevState => ({
                  cart: [...prevState.cart, {

                    "productId": data.productId,
                    "shopId": data.shopId,
                    "title": data.title,
                    "lastPrice": data.lastPrice,
                    "sellPrice": data.sellPrice,
                    "warranty": data.warranty,
                    "rating": data.rating,
                    "stock": data.stock,
                    "brand": data.brand,
                    "model": data.model,
                    "category": data.category,
                    "date": data.date,
                    "image1": data.image1,
                    "count":1,
                  }]
                }))
                this.getTotal();
                alert("The product added to cart. "+data.title)
            })

        }else{
            alert("The product has been added to cart.")
        }
    };

    increase = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item.productId === id){
                item.count += 1;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    reduction = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item.productId === id){
                item.count === 1 ? item.count = 1 : item.count -=1;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    removeProduct = id =>{
        if(window.confirm("Do you want to delete this product?")){
            const {cart} = this.state;
            cart.forEach((item1, index) =>{
                if(item1.productId === id){
                    cart.splice(index, 1)
                }
            })
            this.setState({cart: cart});
            this.getTotal();
        }
    };
    /////////////////////////
    // remove2 = (id) =>{
    //     if(window.confirm("Do you want to delete this product?????????????")){
    //         const {payment} = this.state;
    //         payment.forEach((item2, index) =>{
    //             if(item2.productd === id){
    //                 payment.splice(index, 1)
    //             }
    //         })
    //         this.setState({payment: payment});
    //         this.getTotal();
    //     }
    // };
    /////////////

    getTotal = ()=>{
        const{cart} = this.state;
        const res = cart.reduce((prev, item) => {
            return prev + (item.sellPrice * item.count);
        },0)
        this.setState({total: res})

        // const tt = this.state;
        // const cartNo = tt.length;
        // this.setState({cartNo: cartNo})
        // alert(cartNo)
    };

    //////////////////////////////////////////////////////////////
    buythins =(id) =>{
        const {products, payment,cart} = this.state;
        const data = products.filter(product =>{
            return product.productId === id
        })
        // this.setState({payment: [...payment,...data]})
        this.setState({cart: [...cart,...data]})
        this.getTotal();
    }
    ////////////////////////////////////////////////////////////

    componentDidUpdate(){
        localStorage.setItem('dataCart', JSON.stringify(this.state.cart))
        localStorage.setItem('dataTotal', JSON.stringify(this.state.total))

        localStorage.setItem('dataBuythins', JSON.stringify(this.state.payment))
    };

    componentDidMount(){
        const dataCart = JSON.parse(localStorage.getItem('dataCart'));
        if(dataCart !== null){
            this.setState({cart: dataCart});
        }
        const dataTotal = JSON.parse(localStorage.getItem('dataTotal'));
        if(dataTotal !== null){
            this.setState({total: dataTotal});
        }

        const dataBuythins = JSON.parse(localStorage.getItem('dataBuythins'));
        if(dataBuythins !== null){
            this.setState({payment: dataBuythins});
        }
    }

    render() {
        const { cart,cartNo,total,shops,payment} = this.state;
        const {addCart,reduction,increase,removeProduct,getTotal,buythins,remove2} = this;
        return (
            <DataContext.Provider
            value={{addCart, cart , cartNo, reduction,increase,removeProduct,total,getTotal,shops,buythins,payment,remove2}}>
                {this.props.children}
            </DataContext.Provider>
        )
    }
}
