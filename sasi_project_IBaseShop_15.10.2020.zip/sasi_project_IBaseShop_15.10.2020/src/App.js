import React, {Component} from 'react';
import logo from './logo.svg';
import './App.css';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton } from "@material-ui/core";
import Rating from 'material-ui-rating';
import {Grid, CardActions,CardMedia, CardActionArea, Box, Card, CardContent, TextField} from '@material-ui/core';
import { AccountCircle } from "@material-ui/icons";
//import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import MenuIcon from '@material-ui/icons/Menu';
import SearchIcon from '@material-ui/icons/Search';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import { Route, Link, BrowserRouter as Router, Switch } from 'react-router-dom';
import Ibaseshop from './ibaseshopLogo.png';

import { makeStyles } from '@material-ui/core/styles';

import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import PopupState, { bindTrigger, bindMenu } from 'material-ui-popup-state';


import {DataContext} from './component/Data'

import {Data} from './component/Data';


import ApiService from "./ApiService";

import Home from './component/home';
import Footer from './component/footer';
import Profile from './component/profile';
import Search from './component/search';
import Product from './component/product';
import AddItem from './component/additem';
import SignIn from './component/signIn';
import SignUp from './component/signUp';

import CreateShop from './component/createShop';
import Payment from './component/Payment';
import BuyingThings from './component/BuyingThings';
import Shop from './component/ShopSide';





import Admin from './component/admin/admin';
import ShopDetails from './component/admin/shopDetails';
import AdminShopEdite from './component/admin/adminShopEdite';
import UserDetails from './component/admin/userDetails';
import EditUser from './component/admin/editUser';
import ProductDetails from './component/admin/productDetails';
import EditProduct from './component/editProduct';
import OrderDetails from './component/admin/orderDetails';
import EditOrder from './component/admin/editOrder';
import AddOrder from './component/admin/addOrders';
import Cart from './component/cart';









//import PicUploadNoCrop from './component/imgCrop';





class App extends Component {


  constructor(props){
    super(props);
    this.state = {
      searchKey:'',
      locationSelectDiv:'show',
      currentUser: undefined,
      logIn:false,
      shopId:'',
      shopName:'',
      admin:'',
      showAdminBoard:'',
      roles:[],
      products:[],
    };
  }

  componentDidMount(){

    const authResult = new URLSearchParams(window.location.search);
    const searchKey = authResult.get('searchKey');

    let user = localStorage.getItem("user");
    if (localStorage.getItem('userName')) {

      this.setState({
        currentUser: user,
        logIn:true,
        searchKey:searchKey,
         admin:localStorage.getItem("admin"),
      //  showAdminBoard: user.roles.includes("ROLE_ADMIN")
        //roles:user.roles,
      });
    }






    this.loadShop()


  };


  loadShop = () => {
    ApiService.getShopByUserId(localStorage.getItem("userId"))
    .then(res => {
        const shop = res.data;
        this.setState({
            shopId:res.data.shopId,
            shopName:res.data.shopName,
        })
    })
  }





  onChangeSearch = (e) =>{
    this.setState({
      searchKey:e.target.value,
    })
  }


  logOut = () => {
      localStorage.clear();
      window.location.href='./';
      //window.location.reload();
    }

//  searchFun=(e)=>{
    //{pathname: "/search", search: `id=${this.state.search}`,}

    //this.props.history.push({ pathname: "/search"});
  //  this.props.history.push('/userDetails');

//   const state = { 'page_id': 1, 'user_id': 5 }
// const title = ''
// const url = '/search'
//
//     this.props.history.pushState(state, title, url)
  //}



  render() {
      const {addCart,cart,buythins,cartNo} = this.context;

      const { currentUser } = this.state;
      const products = this.state.products;

    return (
      <Router>
          <div className="App">



            <AppBar position="static" className='App-AppBar' style={{backgroundColor:'#03a9f4', color:'white'}}>
              <Toolbar>
                <IconButton edge="start"   color="inherit" aria-label="menu">
                    <MenuIcon style={{fontSize:'40px'}} />
                </IconButton>
                  <Button href="/" className='App-LogoDiv'><img src={Ibaseshop} style={{width:'50px',color:'white'}}/><strong style={{fontSize:'20px',marginTop:'15px',color:'white'}} className='logoText'>Ibaseshop</strong></Button>

                <div className='App-SearchDiv'>

                    <IconButton edge="start"   style={{width:'25px',height:'25px',marginTop:'2px',marginLeft:'2px',float:'right'}}  href={`/search?searchKey=${this.state.searchKey}&minPrice=0&maxPrice=10000000&warranty=0`}  >
                        <SearchIcon style={{fontSize:'40px',marginTop:'-5px'}} />
                    </IconButton>

                  <input type='text' value={this.state.searchKey} placeholder="Search for electronics" onChange={this.onChangeSearch} className='searchIP'/>
                </div>

                <Paper style={{'backgroundColor': '#1a237e', 'color': '#c5cae9','flexGrow': '1'}} elevation={0}>

                </Paper>


                <Paper style={{backgroundColor: '#03a9f4', color: '#fff',}} elevation={0}>


                  <Button href="/cart" style={{fontSize:'17px',color:'white'}}>
                    <ShoppingCartIcon style={{height:'30px'}}/>
                    <strong>Cart</strong><sup style={{backgroundColor:'red',marginTop:'-25px',textAlign:'center',paddingRight:'3px',paddingLeft:'3px'}}></sup>
                  </Button>
                  {/*<Button style={{fontSize:'17px',color:'white'}}>
                    <LocationOnIcon style={{height:'30px',}}/>

                    <strong>jaffna</strong>
                  </Button>*/}

                  {!this.state.logIn&&(
                      <Button href="/signin" style={{fontSize:'17px',color:'white'}}>
                            <strong>SignIn</strong>
                      </Button>
                  )}

                  {/*{localStorage.getItem("admin")&&(
                      <Button href="/admin" style={{fontSize:'17px',color:'white',marginRight:'10px'}}>
                            <strong>Admin</strong>
                      </Button>
                  )}*/}

                  {this.state.logIn&&(
                    <PopupState variant="popover" popupId="demo-popup-menu"  >
                      {(popupState) => (
                        <React.Fragment>
                          <Button  style={{fontSize:'17px',fontWeight:'bold',color:'white'}} {...bindTrigger(popupState)}>
                            <AccountCircle style={{height:'30px',marginRight:'5px'}}/>{localStorage.getItem('userName')}
                          </Button>
                          <Menu {...bindMenu(popupState)} style={{marginTop:'40px'}} >
                            <MenuItem onClick={popupState.close} style={{width:'160px'}} href="/profile" ><a href="/profile" style={{color:'black',textDecoration:'none',width:'160px'}}>{localStorage.getItem('userName')}</a></MenuItem>
                            {this.state.admin&&(
                                <MenuItem onClick={popupState.close}><a href="/admin" style={{color:'black',textDecoration:'none',width:'160px'}}>Admin</a></MenuItem>
                            )}
                            {!this.state.shopId&&(
                                <MenuItem onClick={popupState.close}><a href="/createShop" style={{color:'black',textDecoration:'none',width:'160px'}}>Create Shop</a></MenuItem>
                            )}

                            {this.state.shopId&&(
                                <MenuItem onClick={popupState.close}><a href={"/shop/"+this.state.shopId} style={{color:'black',textDecoration:'none',width:'160px'}}>{this.state.shopName}</a></MenuItem>
                            )}


                            <MenuItem onClick={popupState.close} onClick={this.logOut}>Log Out</MenuItem>
                          </Menu>
                        </React.Fragment>
                      )}
                    </PopupState>
                  )}





                </Paper>
              </Toolbar>

            </AppBar>

            {/*<div className='topBar2'>
            <Button href="/deals" style={{fontSize:'17px',color:'red',height:'30px',marginLeft:'90px'}}>
              <strong>Deals</strong>
            </Button>
            </div>*/}



            <div className='switchDiv' style={{ minHeight: `${window.innerHeight-400}px` }}>
            <Data>
              <Switch>
                <Route exact path={["/", "/home"]} component={Home} />
                <Route exact path={["/profile"]} component={Profile} />
                <Route exact path={["/search"]} component={Search} />
                <Route exact path={["/product/:id"]} component={Product} />
                <Route exact path={["/additem"]} component={AddItem} />
                <Route exact path={["/signIn"]} component={SignIn} />
                <Route exact path={["/signUp"]} component={SignUp} />

                <Route exact path={["/createShop"]} component={CreateShop} />
                <Route exact path={["/shop/:id"]} component={Shop} />



                <Route exact path={["/admin"]} component={Admin} />
                <Route exact path={["/shopDetails"]} component={ShopDetails} />
                <Route exact path={["/adminShopEdite/:id"]} component={AdminShopEdite} />
                <Route exact path={["/userDetails"]} component={UserDetails} />
                <Route exact path={["/editUser/:id"]} component={EditUser} />
                <Route exact path={["/productDetails"]} component={ProductDetails} />
                <Route exact path={["/editProduct/:id"]} component={EditProduct} />
                <Route exact path={["/orderDetails"]} component={OrderDetails} />
                <Route exact path={["/editOrder/:id"]} component={EditOrder} />
                <Route exact path={["/addOrder"]} component={AddOrder} />
                <Route exact path={["/cart"]} component={Cart} />
                <Route exact path={["/payment"]} component={Payment} />










              </Switch>
            </Data>
            </div>
            <Footer/>


        </div>
    </Router>
    );
  }
}

export default App;
