import axios from 'axios';

const USER_API_BASE_URL = 'http://localhost:8080/api/';

class ApiService {

  register(user) {
      return axios.post(USER_API_BASE_URL + "auth/signup", user);
  }

  login(regis) {
      return axios.post(USER_API_BASE_URL + "auth/signin", regis)
  }





  getAllUsers() {
      return axios.get(USER_API_BASE_URL + "auth/user")
  }

  getUserById(userid) {
      return axios.get(USER_API_BASE_URL + "auth/user/" + userid)
  }

  userUpdate(UPuser) {
      return axios.put(USER_API_BASE_URL + "auth/user/"+ UPuser.userId , UPuser)
  }



  deleteUser(userId) {
      return axios.delete(USER_API_BASE_URL + "auth/user/"+ userId)
  }

    viewUserById(userId){
        return axios.get(USER_API_BASE_URL + 'auth/user/' + userId);
    }

    getAllUsers(pageSize,pageNo){
        return axios.get(USER_API_BASE_URL + 'auth/user?pageSize='+pageSize + '&pageNo=' + pageNo);
    }

    deleteUserById(userId){
        return axios.delete(USER_API_BASE_URL + 'auth/user/' + userId);
    }

    viewUserByUserName(userName){
        return axios.get(USER_API_BASE_URL + 'auth/user?userName=' + userName);
    }




    getAllProducts(pageNo,pageSize){
      return axios.get(USER_API_BASE_URL + 'products?pageNo=' + pageNo + '&pageSize=' + pageSize);
    }

    getProductById(productId){
        return axios.get(USER_API_BASE_URL + 'products/' + productId);
    }
    getProductByShopId(shopId){
        return axios.get(USER_API_BASE_URL + 'products?shopId=' + shopId);
    }
    updateProduct(product){
        return axios.put(USER_API_BASE_URL + 'products/' + product.productId, product);
    }

    addProduct(product){
        return axios.post(USER_API_BASE_URL + 'products', product);

    }
    getProductBySearchKey(searchKey,minPrice,maxPrice,warranty){
        return axios.get(USER_API_BASE_URL + 'products?search=' + searchKey + '&minPrice=' + minPrice + '&maxPrice=' + maxPrice + '&warranty=' + warranty);
    }
    deleteProduct(productId){
        return axios.delete(USER_API_BASE_URL + 'products/' + productId);
    }




    getAllOrders(pageNo,pageSize){
        return axios.get(USER_API_BASE_URL+'orders?pageNo=' + pageNo + '&pageSize=' + pageSize);
    }
    getOrderById(orderId){
        return axios.get(USER_API_BASE_URL + 'orders/' + orderId);
    }
    editOrder(order){
        return axios.put(USER_API_BASE_URL + 'orders/' + order.id, order);
    }
    deleteOrderById(orderId){
        return axios.delete(USER_API_BASE_URL + 'orders/' + orderId);
    }
    addOrder(order) {
        return axios.post(USER_API_BASE_URL,+'orders', order);
    }



    getAllShops(){
      return axios.get(USER_API_BASE_URL + 'shops');
    }
    createShop(shop){
        return axios.post(USER_API_BASE_URL + 'shops' , shop);
    }
    deleteShopById(shopId){
          return axios.delete(USER_API_BASE_URL + 'shops/'+shopId);
    }
    getShopById(shopId) {
        return axios.get(USER_API_BASE_URL + 'shops/' + shopId);
    }
    getShopByUserId(userId) {
        return axios.get(USER_API_BASE_URL + 'shops?userId=' + userId);
    }
    updateShop(shop){
        return axios.put(USER_API_BASE_URL + 'shops/' + shop.shopId, shop);
    }



    getFeedbackByProductId(productId){
        return axios.get(USER_API_BASE_URL + 'feedback?productId='+productId);
    }
    countFeedbackByProductId(productId){
        return axios.get(USER_API_BASE_URL + 'feedback?pro='+productId);
    }


}

export default new ApiService();
